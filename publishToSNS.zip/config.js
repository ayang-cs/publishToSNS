const config = {
    PROD: {
        AWS: {
            ACCOUNT_ID: 742345837186,
            REGION: "us-west-2",
        }
    },
    DEV: {
        AWS: {
            ACCOUNT_ID: 410986195230,
            REGION: "us-west-2"
        }
    }
}

module.exports = config